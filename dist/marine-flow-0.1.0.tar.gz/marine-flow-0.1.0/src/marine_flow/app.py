from prefect import flow, task

@task
def say_hello():
	print("Hello, World! I'm Marvin!")


@flow
def marvin_flow():
	say_hello()


marvin_flow() # "Hello, World! I'm Marvin!"
